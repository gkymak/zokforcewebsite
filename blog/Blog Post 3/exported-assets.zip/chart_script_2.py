import plotly.graph_objects as go
import json

# Data provided
data = [
    {"metric": "Trust in AI Systems", "improvement": 40, "type": "increase"}, 
    {"metric": "Regulatory Compliance", "improvement": 85, "type": "increase"}, 
    {"metric": "Bias Incidents", "improvement": -60, "type": "decrease"}, 
    {"metric": "Customer Satisfaction", "improvement": 27, "type": "increase"}, 
    {"metric": "Revenue Growth", "improvement": 150, "type": "increase"}, 
    {"metric": "Risk Events", "improvement": -75, "type": "decrease"}
]

# Process the data with proper labels and values
metrics = []
values = []
bar_colors = []

# Define colors for positive (increases) and negative (decreases) values
positive_colors = ['#1FB8CD', '#2E8B57', '#5D878F', '#D2BA4C']
negative_colors = ['#DB4545', '#B4413C']

pos_color_idx = 0
neg_color_idx = 0

for item in data:
    # Create abbreviated but accurate metric names (under 15 characters)
    if item["metric"] == "Trust in AI Systems":
        metrics.append("Trust in AI")
    elif item["metric"] == "Regulatory Compliance":
        metrics.append("Reg Compliance")
    elif item["metric"] == "Bias Incidents":
        metrics.append("Bias Incidents")
    elif item["metric"] == "Customer Satisfaction":
        metrics.append("Cust Satisfact")
    elif item["metric"] == "Revenue Growth":
        metrics.append("Revenue Growth")
    elif item["metric"] == "Risk Events":
        metrics.append("Risk Events")
    
    # Keep original values (negative for decreases)
    values.append(item["improvement"])
    
    # Assign colors based on increase/decrease
    if item["type"] == "increase":
        bar_colors.append(positive_colors[pos_color_idx % len(positive_colors)])
        pos_color_idx += 1
    else:
        bar_colors.append(negative_colors[neg_color_idx % len(negative_colors)])
        neg_color_idx += 1

# Create the vertical bar chart
fig = go.Figure(data=[
    go.Bar(
        x=metrics,
        y=values,
        marker_color=bar_colors,
        text=[f"{v}%" for v in values],
        textposition='outside',
        textfont=dict(size=14)
    )
])

# Update layout with professional styling
fig.update_layout(
    title="Ethical AI Impact on Key Metrics",
    xaxis_title="Key Metrics",
    yaxis_title="Change (%)",
    showlegend=False
)

# Update traces and axes according to instructions
fig.update_traces(cliponaxis=False)

# Format y-axis to show percentages and include zero line
fig.update_yaxes(
    ticksuffix="%",
    zeroline=True,
    zerolinecolor="black",
    zerolinewidth=1
)

# Add a horizontal line at y=0 for better clarity
fig.add_hline(y=0, line_dash="solid", line_color="black", line_width=1)

# Save as both PNG and SVG
fig.write_image("ethical_ai_impact.png")
fig.write_image("ethical_ai_impact.svg", format="svg")

# Display the chart
fig.show()