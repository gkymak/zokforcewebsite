// Progress bar functionality
function updateProgressBar() {
    const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolled = (winScroll / height) * 100;
    const progressBar = document.getElementById("progressBar");
    if (progressBar) {
        progressBar.style.width = scrolled + "%";
    }
}

// Smooth scrolling for navigation links
function initSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const headerHeight = document.querySelector('.header').offsetHeight || 80;
                const targetPosition = targetSection.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Update active states immediately
                setTimeout(() => {
                    updateActiveNavigation();
                }, 100);
            }
        });
    });
}

// Active navigation state
function updateActiveNavigation() {
    const sections = document.querySelectorAll('.content-section[id], #toc, #executive-summary');
    const navLinks = document.querySelectorAll('.nav-link, .toc-link');
    
    let current = '';
    const scrollPosition = window.pageYOffset + 120; // Account for header height
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        
        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        const href = link.getAttribute('href');
        if (href === '#' + current) {
            link.classList.add('active');
        }
    });
}

// Intersection Observer for animations
function initIntersectionObserver() {
    if ('IntersectionObserver' in window) {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                    // Add a small delay for staggered animation effect
                    const delay = Array.from(entry.target.parentElement.children).indexOf(entry.target) * 100;
                    setTimeout(() => {
                        entry.target.style.transitionDelay = delay + 'ms';
                    }, 0);
                }
            });
        }, observerOptions);
        
        // Observe elements for animation
        const animatedElements = document.querySelectorAll(
            '.pillar-card, .case-study-card, .phase-card, .metric-card, .tech-item, .framework-card, .trend-item, .recommendation-card'
        );
        
        animatedElements.forEach(el => {
            observer.observe(el);
        });
    }
}

// Button click handlers
function initButtonHandlers() {
    // CTA buttons
    const consultationBtn = document.querySelector('.cta-buttons .btn--primary');
    const downloadBtn = document.querySelector('.cta-buttons .btn--outline');
    
    if (consultationBtn) {
        consultationBtn.addEventListener('click', function() {
            // In a real implementation, this would open a contact form or redirect
            alert('Thank you for your interest! Please contact us at contact@zokforce.com to schedule your consultation.');
        });
    }
    
    if (downloadBtn) {
        downloadBtn.addEventListener('click', function() {
            // In a real implementation, this would trigger a download
            alert('Framework download will be available soon. Please contact us for early access.');
        });
    }
}

// Statistics counter animation
function animateCounters() {
    const statNumbers = document.querySelectorAll('.stat-number, .metric-value');
    
    const animateValue = (element, start, end, duration, suffix = '') => {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const current = Math.floor(progress * (end - start) + start);
            element.textContent = current + suffix;
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !entry.target.classList.contains('counter-animated')) {
                entry.target.classList.add('counter-animated');
                const text = entry.target.textContent;
                const hasPercent = text.includes('%');
                const hasMinus = text.includes('-');
                const hasPlus = text.includes('+');
                const number = parseInt(text.replace(/[^\d]/g, ''));
                
                if (number > 0) {
                    let suffix = '';
                    if (hasPercent) suffix = '%';
                    if (hasMinus) suffix = '%';
                    if (hasPlus) suffix = '%';
                    
                    animateValue(entry.target, 0, number, 2000, suffix);
                    
                    // Add prefix after animation
                    setTimeout(() => {
                        if (hasMinus) {
                            entry.target.textContent = '-' + entry.target.textContent;
                        } else if (hasPlus) {
                            entry.target.textContent = '+' + entry.target.textContent;
                        }
                    }, 2000);
                }
            }
        });
    }, { threshold: 0.5 });
    
    statNumbers.forEach(stat => observer.observe(stat));
}

// Scroll to top functionality
function addScrollToTop() {
    const scrollButton = document.createElement('button');
    scrollButton.innerHTML = '↑';
    scrollButton.className = 'scroll-to-top';
    scrollButton.setAttribute('aria-label', 'Scroll to top');
    
    scrollButton.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    
    document.body.appendChild(scrollButton);
    
    // Show/hide scroll button based on scroll position
    function toggleScrollButton() {
        if (window.pageYOffset > 300) {
            scrollButton.classList.add('visible');
        } else {
            scrollButton.classList.remove('visible');
        }
    }
    
    window.addEventListener('scroll', debounce(toggleScrollButton, 100));
}

// Ensure SVG diagrams load properly
function initDiagrams() {
    const diagramObjects = document.querySelectorAll('object[data$=".svg"]');
    
    diagramObjects.forEach(obj => {
        obj.addEventListener('load', function() {
            // SVG loaded successfully
            console.log('SVG diagram loaded successfully');
        });
        
        obj.addEventListener('error', function() {
            // Fallback to img if object fails
            const fallbackImg = this.querySelector('img');
            if (fallbackImg) {
                this.style.display = 'none';
                fallbackImg.style.display = 'block';
            }
        });
    });
}

// Reading time estimation and update
function updateReadingTime() {
    const content = document.querySelector('.main-content');
    if (!content) return;
    
    const text = content.textContent || content.innerText || '';
    const wordsPerMinute = 200;
    const words = text.trim().split(/\s+/).length;
    const readingTime = Math.ceil(words / wordsPerMinute);
    
    // Update the reading time in the hero section
    const readingTimeElements = document.querySelectorAll('.meta-item');
    readingTimeElements.forEach(element => {
        if (element.textContent.includes('min read')) {
            element.textContent = `${readingTime} min read`;
        }
    });
}

// Performance optimization - debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Mobile menu functionality
function initMobileMenu() {
    const header = document.querySelector('.header');
    const nav = document.querySelector('.header-nav');
    
    if (window.innerWidth <= 768) {
        // Check if mobile menu button already exists
        if (!document.querySelector('.mobile-menu-toggle')) {
            const menuButton = document.createElement('button');
            menuButton.className = 'mobile-menu-toggle btn btn--outline';
            menuButton.innerHTML = '☰';
            menuButton.setAttribute('aria-label', 'Toggle mobile menu');
            
            menuButton.addEventListener('click', function() {
                nav.classList.toggle('mobile-open');
                this.innerHTML = nav.classList.contains('mobile-open') ? '✕' : '☰';
            });
            
            header.querySelector('.container').appendChild(menuButton);
            
            // Add mobile styles
            if (!document.querySelector('#mobile-styles')) {
                const style = document.createElement('style');
                style.id = 'mobile-styles';
                style.textContent = `
                    @media (max-width: 768px) {
                        .mobile-menu-toggle {
                            display: block;
                            padding: var(--space-8);
                            min-width: auto;
                        }
                        
                        .header-nav {
                            display: none;
                            position: absolute;
                            top: 100%;
                            left: 0;
                            right: 0;
                            background: var(--color-surface);
                            border-top: 1px solid var(--color-border);
                            padding: var(--space-16);
                            flex-direction: column;
                            gap: var(--space-12);
                            box-shadow: var(--shadow-md);
                        }
                        
                        .header-nav.mobile-open {
                            display: flex;
                        }
                        
                        .header {
                            position: relative;
                        }
                    }
                `;
                document.head.appendChild(style);
            }
        }
    }
}

// Handle window resize
function handleWindowResize() {
    // Reinitialize mobile menu if needed
    if (window.innerWidth <= 768) {
        initMobileMenu();
    } else {
        // Remove mobile menu button if screen is large
        const mobileButton = document.querySelector('.mobile-menu-toggle');
        if (mobileButton) {
            mobileButton.remove();
        }
        
        // Ensure nav is visible on large screens
        const nav = document.querySelector('.header-nav');
        if (nav) {
            nav.classList.remove('mobile-open');
            nav.style.display = 'flex';
        }
    }
}

// Initialize all functionality
function init() {
    console.log('Initializing ZOKFORCE blog application...');
    
    // Initialize core functionality
    initSmoothScrolling();
    initButtonHandlers();
    initDiagrams();
    updateReadingTime();
    addScrollToTop();
    
    // Initialize performance-optimized scroll handlers
    const debouncedProgressUpdate = debounce(updateProgressBar, 10);
    const debouncedNavUpdate = debounce(updateActiveNavigation, 100);
    
    window.addEventListener('scroll', () => {
        debouncedProgressUpdate();
        debouncedNavUpdate();
    });
    
    // Initialize intersection observer for animations
    initIntersectionObserver();
    animateCounters();
    
    // Initialize responsive functionality
    window.addEventListener('resize', debounce(handleWindowResize, 250));
    handleWindowResize(); // Initial call
    
    // Initial calls
    updateProgressBar();
    updateActiveNavigation();
    
    console.log('ZOKFORCE blog application initialized successfully');
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('Application error:', e.error);
});

// Handle page visibility changes for performance
document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
        // Page is visible, update states
        updateProgressBar();
        updateActiveNavigation();
    }
});

// Wait for DOM to be fully loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    // DOM is already loaded
    init();
}

// Export functions for potential external use
window.ZokforceApp = {
    updateProgressBar,
    initSmoothScrolling,
    updateActiveNavigation,
    init
};