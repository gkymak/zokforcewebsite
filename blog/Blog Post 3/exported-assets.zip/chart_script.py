import plotly.graph_objects as go
import numpy as np

# Data for the six pillars with exact colors from JSON and proper abbreviations
pillars_data = [
    {"pillar": "Transparency", "full_name": "Transparency & Explainability", "icon": "👁️", "color": "#2563eb", "desc": "AI decisions"},
    {"pillar": "Fairness", "full_name": "Fairness & Non-Discrimination", "icon": "⚖️", "color": "#059669", "desc": "Equitable"},
    {"pillar": "Privacy", "full_name": "Privacy & Security", "icon": "🛡️", "color": "#dc2626", "desc": "Data protect"},
    {"pillar": "Accountability", "full_name": "Accountability", "icon": "✅", "color": "#7c3aed", "desc": "Clear resp"},
    {"pillar": "Reliability", "full_name": "Reliability & Safety", "icon": "⛑️", "color": "#ea580c", "desc": "Safe perform"},
    {"pillar": "Human Oversight", "full_name": "Human Agency & Oversight", "icon": "👤⚙️", "color": "#0891b2", "desc": "Human control"}
]

# Calculate hexagonal positions (6 points around circle)
n_points = 6
angles = np.linspace(0, 2*np.pi, n_points, endpoint=False)
# Start from top and go clockwise
angles = angles + np.pi/2
radius = 3

# Calculate positions for outer hexagons
x_coords = [radius * np.cos(angle) for angle in angles]
y_coords = [radius * np.sin(angle) for angle in angles]

# Create figure
fig = go.Figure()

# Add connecting lines between all hexagon points to show interconnection
for i in range(n_points):
    for j in range(i+1, n_points):
        fig.add_trace(go.Scatter(
            x=[x_coords[i], x_coords[j]], 
            y=[y_coords[i], y_coords[j]],
            mode='lines',
            line=dict(color='#D1D5DB', width=1.5),
            showlegend=False,
            hoverinfo='skip'
        ))

# Add pillar hexagons with better formatting
for i, pillar in enumerate(pillars_data):
    fig.add_trace(go.Scatter(
        x=[x_coords[i]],
        y=[y_coords[i]],
        mode='markers+text',
        marker=dict(
            size=120,
            color=pillar['color'],
            symbol='hexagon',
            line=dict(width=4, color='white')
        ),
        text=f"<b>{pillar['icon']}</b><br><b>{pillar['pillar']}</b>",
        textposition='middle center',
        textfont=dict(size=12, color='white', family='Arial Black'),
        name=pillar['pillar'],
        hovertemplate='<b>%{customdata[0]}</b><br>%{customdata[1]}<extra></extra>',
        customdata=[[pillar['full_name'], pillar['desc']]],
        showlegend=False
    ))

# Update layout for better appearance
fig.update_layout(
    title='Six Pillars of Ethical AI',
    xaxis=dict(
        visible=False, 
        range=[-4.5, 4.5],
        showgrid=False,
        zeroline=False
    ),
    yaxis=dict(
        visible=False, 
        range=[-4.5, 4.5], 
        scaleanchor="x", 
        scaleratio=1,
        showgrid=False,
        zeroline=False
    ),
    plot_bgcolor='white',
    paper_bgcolor='white',
    font=dict(family='Arial', size=14)
)

fig.update_traces(cliponaxis=False)

# Save as both PNG and SVG
fig.write_image("ethical_ai_pillars.png")
fig.write_image("ethical_ai_pillars.svg", format="svg")

fig.show()