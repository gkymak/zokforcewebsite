import plotly.graph_objects as go
import plotly.express as px
import json

# Data for the AI governance roadmap with specified colors
data = [
    {"phase": "Phase 1: Assessment & Foundation", "duration": "Months 1-3", "activities": ["AI System Inventory", "Risk Assessment", "Team Formation", "Stakeholder Mapping"], "start": 1, "end": 3, "color": "#2563eb"},
    {"phase": "Phase 2: Framework Development", "duration": "Months 4-6", "activities": ["Policy Creation", "Governance Structure", "Ethics Guidelines", "Compliance Framework"], "start": 4, "end": 6, "color": "#059669"},
    {"phase": "Phase 3: Implementation & Tools", "duration": "Months 7-9", "activities": ["XAI Tools Deployment", "Monitoring Systems", "Bias Detection Tools", "Training Programs"], "start": 7, "end": 9, "color": "#ea580c"},
    {"phase": "Phase 4: Monitoring & Optimization", "duration": "Months 10-12", "activities": ["Continuous Auditing", "Performance Metrics", "Stakeholder Feedback", "Framework Refinement"], "start": 10, "end": 12, "color": "#7c3aed"}
]

# Create the figure
fig = go.Figure()

# Phase names that fit 15 character limit but retain key info
phase_names = ["Phase 1: Assess", "Phase 2: Framework", "Phase 3: Implement", "Phase 4: Monitor"]

# Add bars for each phase
for i, phase_data in enumerate(data):
    # Create detailed hover text
    activities_text = "<br>".join([f"• {activity}" for activity in phase_data["activities"]])
    hover_text = f"{phase_data['phase']}<br>{phase_data['duration']}<br><br>Key Activities:<br>{activities_text}"
    
    # Add horizontal bar
    fig.add_trace(go.Bar(
        x=[phase_data['end'] - phase_data['start'] + 1],
        y=[phase_names[i]],
        orientation='h',
        marker_color=phase_data['color'],
        name=f"Months {phase_data['start']}-{phase_data['end']}",
        hovertemplate=hover_text + "<extra></extra>",
        base=[phase_data['start'] - 1],
        text=f"M{phase_data['start']}-{phase_data['end']}",
        textposition="inside",
        textfont=dict(color="white", size=11, family="Arial Black")
    ))

# Update layout for professional appearance
fig.update_layout(
    title="AI Governance Implementation Roadmap",
    xaxis_title="Timeline (Months)",
    yaxis_title="Implementation Phases",
    showlegend=True,
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    xaxis=dict(
        range=[0, 13],
        tickvals=list(range(1, 13)),
        ticktext=[f"M{i}" for i in range(1, 13)],
        showgrid=True,
        gridcolor="rgba(128,128,128,0.2)",
        gridwidth=1,
        zeroline=False
    ),
    yaxis=dict(
        categoryorder='array', 
        categoryarray=["Phase 4: Monitor", "Phase 3: Implement", "Phase 2: Framework", "Phase 1: Assess"],
        showgrid=False,
        zeroline=False
    ),
    plot_bgcolor="white",
    paper_bgcolor="white",
    bargap=0.2,  # Reduce gap between bars for more compact look
    font=dict(family="Arial", size=12)
)

# Update traces to remove clipping and enhance appearance
fig.update_traces(
    cliponaxis=False,
    marker_line_color="white",
    marker_line_width=1
)

# Update x-axis for better professional look
fig.update_xaxes(
    showline=True,
    linewidth=1,
    linecolor='rgba(128,128,128,0.5)',
    mirror=False
)

# Update y-axis for better professional look
fig.update_yaxes(
    showline=False,
    linewidth=1,
    linecolor='rgba(128,128,128,0.5)',
    mirror=False
)

# Save as PNG and SVG
fig.write_image("chart.png")
fig.write_image("chart.svg", format="svg")

fig.show()